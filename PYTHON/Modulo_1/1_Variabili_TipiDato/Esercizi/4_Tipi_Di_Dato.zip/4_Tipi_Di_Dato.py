# Esercizio 1 

x = 10 
y = 4.5
z = "ciao"

print(type(x))
print(type(y))
print(type(z))


# Esercizio 2

a = 10
b = 3.7
somma = a + b
print(somma, type(somma))


# Esercizio 3

s1 = "Python"
s2 = " è fantastico"
frase = s1 + s2
print(frase)


# Esercizio 4 

x = 5
y = 10
print ( x < y ) #true
print ( x == y ) #false
